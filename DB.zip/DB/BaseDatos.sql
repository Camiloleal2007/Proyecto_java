drop database GestionCita;
Create database GestionCita;
use GestionCita;


CREATE TABLE Usuario (
    id INT PRIMARY KEY AUTO_INCREMENT,
    nombre VARCHAR(100),
    documento VARCHAR(20) unique ,
    telefono VARCHAR(20),
    especialidad VARCHAR(100), 
    correo VARCHAR(100),
    fecha_nacimiento DATE,
    contraseña VARCHAR(50) NOT NULL,
    Rol Enum('Medico','Paciente','Admin')
);
INSERT INTO Usuario (nombre, documento, telefono, especialidad, correo, fecha_nacimiento, contraseña, Rol)
VALUES ('CamiloLeal', '1082911004', '3011946015', NULL, 'Camiloandreslealospino@gmail.com', '2007-02-20', 'camiloleal2007', 'Admin');
INSERT INTO Usuario (nombre, documento, telefono, especialidad, correo, fecha_nacimiento, contraseña, Rol)
VALUES ('Paciente1', '123456789', '3011946015', NULL, 'Camiloandreslealospino@gmail.com', '2007-02-20', 'Paciente1', 'Paciente');
INSERT INTO Usuario (nombre, documento, telefono, especialidad, correo, fecha_nacimiento, contraseña, Rol)
VALUES ('Paciente2', '12345', '3011946015', NULL, 'Camiloandreslealospino@gmail.com', '2007-02-20', 'Paciente2', 'Paciente');
INSERT INTO Usuario (nombre, documento, telefono, especialidad, correo, fecha_nacimiento, contraseña, Rol) 
VALUES 
    ('MedicoGeneral1', '10001', '3001111111', 'General', 'medicogeneral1@example.com', '1980-05-15', 'MedicoGeneral1', 'Medico'),
    ('MedicoGeneral2', '10002', '3002222222', 'General', 'medicogeneral2@example.com', '1985-07-20', 'MedicoGeneral2', 'Medico'),
    ('MedicoGeneral3', '10003', '3003333333', 'General', 'medicogeneral3@example.com', '1990-02-10', 'MedicoGeneral3', 'Medico');

INSERT INTO Usuario (nombre, documento, telefono, especialidad, correo, fecha_nacimiento, contraseña, Rol) 
VALUES 
    ('Odontologo1', '20001', '3101111111', 'Odontología', 'odontologo1@example.com', '1982-09-25', 'Odontologo1', 'Medico'),
    ('Odontologo2', '20002', '3102222222', 'Odontología', 'odontologo2@example.com', '1988-11-30', 'Odontologo2', 'Medico'),
    ('Odontologo3', '20003', '3103333333', 'Odontología', 'odontologo3@example.com', '1995-06-05', 'Odontologo3', 'Medico');

INSERT INTO Usuario (nombre, documento, telefono, especialidad, correo, fecha_nacimiento, contraseña, Rol) 
VALUES 
    ('Pediatra1', '30001', '3201111111', 'Pediatría', 'pediatra1@example.com', '1983-04-12', 'Pediatra1', 'Medico'),
    ('Pediatra2', '30002', '3202222222', 'Pediatría', 'pediatra2@example.com', '1987-08-18', 'Pediatra2', 'Medico'),
    ('Pediatra3', '30003', '3203333333', 'Pediatría', 'pediatra3@example.com', '1992-01-25', 'Pediatra3', 'Medico');
select * from Usuario;

create table CitasActivas(
    id INT AUTO_INCREMENT PRIMARY KEY,
    paciente_nombre VARCHAR(100),
    medico_nombre VARCHAR(100),
    fecha DATE,
    hora VARCHAR(20),
    tipo_cita VARCHAR(100)
);

create table CitasAtendidas(
    id INT AUTO_INCREMENT PRIMARY KEY,
    paciente_nombre VARCHAR(100),
    medico_nombre VARCHAR(100),
    fecha DATE,
    hora VARCHAR(20),
    tipo_cita VARCHAR(100),
    diagnostico varchar(500),
    solucion varchar(5000)
);
select * from CitasActivas;
select * from CitasAtendidas;
DELIMITER //
CREATE PROCEDURE validar_login( in p_documento VARCHAR(20), in p_contraseña VARCHAR(50),OUT rol_usuario VARCHAR(20)
)
BEGIN
    SELECT Rol INTO rol_usuario
    FROM Usuario
    WHERE documento = p_documento AND contraseña = p_contraseña;
    
    IF rol_usuario IS NULL THEN
        SET rol_usuario = 'No encontrado';
    END IF;
END //
DELIMITER ;


DELIMITER //
create procedure Procedimientos (numero int, id int) begin 
if numero=1 then
    select nombre from Usuario where documento=id;
end if;
if numero=2 then
    select correo from Usuario where documento=id;
end if;
if numero=3 then
	select telefono from Usuario where documento=id;
end if;
end//
DELIMITER ;

DELIMITER //
CREATE PROCEDURE CRUD_Usuario(accion ENUM('INSERT', 'UPDATE', 'DELETE'), p_documento VARCHAR(20), p_nombre VARCHAR(100), p_telefono VARCHAR(20), 
p_especialidad VARCHAR(100), p_correo VARCHAR(100), p_fecha_nacimiento DATE, p_contraseña VARCHAR(50),p_Rol ENUM('Medico','Paciente','Admin'),OUT resultado TINYINT
)
BEGIN
    CASE accion
        WHEN 'INSERT' THEN
            IF NOT EXISTS (SELECT 1 FROM Usuario WHERE documento = p_documento) THEN
                INSERT INTO Usuario (documento, nombre, telefono, especialidad, correo, fecha_nacimiento, contraseña, Rol)
                VALUES (p_documento, p_nombre, p_telefono, p_especialidad, p_correo, p_fecha_nacimiento, p_contraseña, p_Rol);
                SET resultado = 1;
            ELSE
                SET resultado = 0;
            END IF;
        WHEN 'UPDATE' THEN
            UPDATE Usuario 
            SET nombre = p_nombre, telefono = p_telefono, especialidad = p_especialidad, 
                correo = p_correo, fecha_nacimiento = p_fecha_nacimiento, 
                contraseña = p_contraseña, Rol = p_Rol
            WHERE documento = p_documento;
        WHEN 'DELETE' THEN
            DELETE FROM Usuario WHERE documento = p_documento;
    END CASE;
END //
DELIMITER ;

DELIMITER //

CREATE PROCEDURE EliminarCita( cita_fecha DATE, cita_hora VARCHAR(20))
BEGIN
    DELETE FROM CitasActivas WHERE fecha = cita_fecha AND hora = cita_hora;
END //

DELIMITER ;

DELIMITER //
CREATE FUNCTION obtenerMedicoPorEspecialidad(especialidadBuscada VARCHAR(100))
RETURNS VARCHAR(100)
DETERMINISTIC
READS SQL DATA
BEGIN
    DECLARE nombreMedico VARCHAR(100);

    SELECT nombre
    INTO nombreMedico
    FROM Usuario
    WHERE Rol= 'Medico'
      AND especialidad = especialidadBuscada
    ORDER BY RAND()
    LIMIT 1;

    RETURN nombreMedico;
END //
DELIMITER ;

DELIMITER $$
CREATE PROCEDURE GestionarCitaMedica ( modo INT, p_paciente_nombre VARCHAR(100),p_medico_nombre VARCHAR(100),p_fecha DATE,p_hora VARCHAR(20),p_tipo_cita VARCHAR(100),OUT mensaje VARCHAR(255)
)
BEGIN
    DECLARE existe INT;

    IF modo = 1 THEN 
         SELECT COUNT(*) INTO existe FROM CitasActivas WHERE medico_nombre = p_medico_nombre AND fecha = p_fecha AND hora = p_hora AND tipo_cita = p_tipo_cita;

	     IF existe > 0 THEN
		     SET mensaje = 'La cita médica ya existe para ese horario.';
		ELSE
			INSERT INTO CitasActivas (paciente_nombre,medico_nombre,fecha,hora,tipo_cita)
			VALUES (p_paciente_nombre,p_medico_nombre,p_fecha,p_hora,p_tipo_cita);
            SET mensaje = 'agregada';
		END IF;

    ELSEIF modo = 0 THEN
        SELECT COUNT(*) INTO existe 
        FROM CitasActivas 
        WHERE paciente_nombre = p_paciente_nombre 
          AND medico_nombre = p_medico_nombre 
          AND fecha = p_fecha 
          AND hora = p_hora 
          AND tipo_cita = p_tipo_cita;

        IF existe = 0 THEN
            SET mensaje = 'No se encontró la cita para eliminar.';
        ELSE
            DELETE FROM CitasActivas 
            WHERE paciente_nombre = p_paciente_nombre 
              AND medico_nombre = p_medico_nombre 
              AND fecha = p_fecha 
              AND tipo_cita = p_tipo_cita;
            SET mensaje = 'Cita médica eliminada correctamente.';
        END IF;

    ELSE
        SET mensaje = 'Modo inválido. Use 1 para agregar o 0 para eliminar.';
    END IF;
END $$
DELIMITER ;

DELIMITER //
CREATE PROCEDURE obtenerCitasMedicas(IN paciente_noombre VARCHAR(255))
BEGIN
    SELECT fecha, hora, medico_nombre, tipo_cita 
    FROM CitasActivas 
    WHERE paciente_nombre = paciente_noombre;
END//
DELIMITER ;

DELIMITER //
CREATE PROCEDURE obtenerCitasMedicasPorMedico(IN medico_nombre_param VARCHAR(255))
BEGIN
    SELECT fecha, hora, paciente_nombre,medico_nombre, tipo_cita 
    FROM CitasActivas 
    WHERE medico_nombre = medico_nombre_param;
END //
DELIMITER ;


DELIMITER //
CREATE PROCEDURE obtenerCitasAtendidas(IN paciente_noombre VARCHAR(255))
BEGIN
    SELECT fecha, hora, paciente_nombre,medico_nombre,tipo_cita, diagnostico, solucion
    FROM CitasAtendidas
    WHERE medico_nombre = paciente_noombre;
END //
DELIMITER ;

DELIMITER //

CREATE PROCEDURE AtenderCita(
    IN p_paciente_nombre VARCHAR(100),
    IN p_medico_nombre VARCHAR(100),
    IN p_fecha DATE,
    IN p_hora VARCHAR(20),
    IN p_tipo_cita VARCHAR(100),
    IN p_diagnostico VARCHAR(500),
    IN p_solucion VARCHAR(5000),
    OUT mensaje VARCHAR(255)
)
BEGIN
    DECLARE existe INT;

    -- Verificar si la cita existe en CitasActivas
    SELECT COUNT(*) INTO existe 
    FROM CitasActivas 
    WHERE paciente_nombre = p_paciente_nombre 
      AND medico_nombre = p_medico_nombre 
      AND fecha = p_fecha 
      AND hora = p_hora 
      AND tipo_cita = p_tipo_cita;

    IF existe > 0 THEN
        INSERT INTO CitasAtendidas (paciente_nombre, medico_nombre, fecha, hora, tipo_cita, diagnostico, solucion)
        VALUES (p_paciente_nombre, p_medico_nombre, p_fecha, p_hora, p_tipo_cita, p_diagnostico, p_solucion);

        DELETE FROM CitasActivas 
        WHERE paciente_nombre = p_paciente_nombre 
          AND medico_nombre = p_medico_nombre 
          AND fecha = p_fecha 
          AND hora = p_hora 
          AND tipo_cita = p_tipo_cita;

        SET mensaje = 'Cita atendida correctamente y guardada en CitasAtendidas.';
    ELSE
        SET mensaje = 'No se encontró la cita en CitasActivas.';
    END IF;
END //

DELIMITER ;
